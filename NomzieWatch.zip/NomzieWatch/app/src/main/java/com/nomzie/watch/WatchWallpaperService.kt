package com.nomzie.watch

import android.content.Context
import android.graphics.*
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.MotionEvent
import android.view.SurfaceHolder
import java.util.Calendar
import kotlin.math.*

private const val TAU = 6.2831855f
private const val TAUD = 6.283185307179586
private val BRASS = 0xFFB9985A.toInt()
private val LUME = 0xFFE3ECC4.toInt()
private val RED = 0xFFE2552F.toInt()
private val GOLD = 0xFFD6B86C.toInt()
private val PLATE = 0xFF0C1713.toInt()
private val CREAM = 0xFFF3EBCB.toInt()
private val RUBY = 0xFFC4362C.toInt()
private val BLACK = 0xFF000000.toInt()
private val goldCols = intArrayOf(0xFFF3DB94.toInt(), 0xFF8A6626.toInt(), 0xFFEBC96F.toInt(), 0xFF755421.toInt(), 0xFFF3DB94.toInt())
private val steelCols = intArrayOf(0xFFEEF1F0.toInt(), 0xFF6F7673.toInt(), 0xFFD5DAD8.toInt(), 0xFF5B615F.toInt(), 0xFFEEF1F0.toInt())
private fun rad(d: Float) = d * 0.017453292f

class WatchWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = WatchEngine()

    inner class WatchEngine : Engine(), SensorEventListener {
        private val handler = Handler(Looper.getMainLooper())
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val path = Path()
        private val sm by lazy { this@WatchWallpaperService.getSystemService(Context.SENSOR_SERVICE) as SensorManager }
        private val serifBold = Typeface.create(Typeface.SERIF, Typeface.BOLD)
        private val sansBold = Typeface.create("sans-serif-medium", Typeface.BOLD)
        private val days = arrayOf("SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT")
        private var bm: Bitmap? = null
        private var ov: Bitmap? = null
        private var cx = 0f; private var cy = 0f; private var u = 1f
        private var reserve = 0.8f; private var crown = 0f
        private var windEnd = 0L; private var last = System.currentTimeMillis()
        private var bt = 0.0
        private var shown = false
        private val tick = object : Runnable {
            override fun run() { draw(); if (shown) handler.postDelayed(this, 33) }
        }

        // ---------- drawing helpers ----------
        private fun pt(color: Int, stroke: Float = 0f): Paint {
            p.reset(); p.isAntiAlias = true; p.color = color
            if (stroke > 0f) { p.style = Paint.Style.STROKE; p.strokeWidth = stroke } else p.style = Paint.Style.FILL
            return p
        }
        private fun disc(c: Canvas, x: Float, y: Float, r: Float, color: Int) = c.drawCircle(x, y, r, pt(color))
        private fun ring(c: Canvas, x: Float, y: Float, r: Float, w: Float, color: Int) = c.drawCircle(x, y, r, pt(color, w))
        private fun line(c: Canvas, x0: Float, y0: Float, x1: Float, y1: Float, w: Float, color: Int) =
            c.drawLine(x0, y0, x1, y1, pt(color, w))
        private fun shaded(c: Canvas, r: Float, sh: Shader) { pt(BLACK); p.shader = sh; c.drawCircle(0f, 0f, r, p) }
        private fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, tf: Typeface, spacing: Float = 0f) {
            pt(color); p.typeface = tf; p.textSize = size; p.textAlign = Paint.Align.CENTER; p.letterSpacing = spacing
            c.drawText(s, x, y + size * 0.35f, p)
        }
        // raised gold lettering: soft shadow underneath, light-to-dark gold gradient on top
        private fun goldText(c: Canvas, s: String, x: Float, y: Float, size: Float, tf: Typeface, spacing: Float) {
            text(c, s, x + .0014f, y + .002f, size, 0xAA000000.toInt(), tf, spacing)
            pt(BLACK); p.typeface = tf; p.textSize = size; p.textAlign = Paint.Align.CENTER; p.letterSpacing = spacing
            p.shader = LinearGradient(0f, y - size * .5f, 0f, y + size * .5f, 0xFFF6E0A0.toInt(), 0xFF9A7329.toInt(), Shader.TileMode.CLAMP)
            c.drawText(s, x, y + size * 0.35f, p)
        }
        private fun spin(perBeat: Double) = ((bt * perBeat) % TAUD).toFloat()

        private val GR = floatArrayOf(.82f, 1f, 1f, .82f)
        private val GO = floatArrayOf(0f, .12f, .42f, .55f)
        private fun gear(c: Canvas, x: Float, y: Float, r: Float, n: Int, rot: Float, cols: IntArray, open: Boolean = true) {
            val k = TAU / n
            path.reset()
            for (i in 0 until n) for (j in 0..3) {
                val a = rot + (i + GO[j]) * k; val rr = r * GR[j]
                val px = x + cos(a) * rr; val py = y + sin(a) * rr
                if (i == 0 && j == 0) path.moveTo(px, py) else path.lineTo(px, py)
            }
            path.close()
            pt(BLACK); p.shader = SweepGradient(x, y, cols, null); c.drawPath(path, p)   // fixed light direction = metallic shimmer as it turns
            c.drawPath(path, pt(0x66000000, .0015f))
            if (open) {
                disc(c, x, y, r * .68f, PLATE)
                ring(c, x, y, r * .68f, r * .035f, cols[2])
                for (i in 0 until 6) {
                    val a = rot + i * TAU / 6
                    line(c, x, y, x + cos(a) * r * .7f, y + sin(a) * r * .7f, r * .1f, cols[2])
                }
                disc(c, x, y, r * .17f, cols[2]); disc(c, x, y, r * .06f, PLATE)
            }
        }
        // rotation for gear B so its teeth sit in the gaps of driver gear A (B lies in direction alpha from A)
        private fun mesh(rotA: Float, nA: Int, nB: Int, alpha: Float): Float {
            val kA = TAU / nA; val kB = TAU / nB
            return -(nA.toFloat() / nB) * (rotA - (alpha - .275f * kA)) + alpha + PI.toFloat() - .775f * kB
        }
        private fun baton(c: Canvas, x: Float, hw: Float) {
            c.drawRect(x - hw, -.405f, x + hw, -.335f, pt(LUME))
            c.drawRect(x - hw, -.405f, x + hw, -.335f, pt(GOLD, .004f))
        }
        private fun hand(c: Canvas, deg: Float, len: Float, w: Float, tail: Float, shade: Boolean) {
            c.save(); c.rotate(deg)
            path.reset(); path.moveTo(0f, tail); path.lineTo(-w, 0f); path.lineTo(0f, -len); path.lineTo(w, 0f); path.close()
            if (shade) c.drawPath(path, pt(0x73000000)) else {
                c.drawPath(path, pt(0xFFF0ECE0.toInt())); c.drawPath(path, pt(GOLD, .004f))
                path.reset(); path.moveTo(0f, tail * .3f); path.lineTo(-w * .5f, 0f); path.lineTo(0f, -len * .88f); path.lineTo(w * .5f, 0f); path.close()
                c.drawPath(path, pt(LUME))
            }
            c.restore()
        }
        private fun secHand(c: Canvas, deg: Float, shade: Boolean) {
            c.save(); c.rotate(deg)
            val col = if (shade) 0x73000000 else RED
            line(c, 0f, .11f, 0f, -.405f, .004f, col); disc(c, 0f, .085f, .018f, col)
            if (!shade) disc(c, 0f, -.3f, .008f, LUME)
            c.restore()
        }

        // ---------- layer 1: case, dial, plate, markers ----------
        private fun buildBase(w: Int, h: Int): Bitmap {
            val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); val c = Canvas(b)
            pt(BLACK); p.shader = RadialGradient(cx, cy, max(w, h) * .7f, 0xFF18221D.toInt(), 0xFF050806.toInt(), Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
            c.translate(cx, cy); c.scale(u, u)
            for (i in 0 until 6) disc(c, 0f, .014f, .472f + i * .005f, 0x12000000)
            shaded(c, .472f, LinearGradient(-.4f, -.45f, .4f, .45f,
                intArrayOf(0xFFF1EEE6.toInt(), 0xFF8A8880.toInt(), 0xFFD6D3C9.toInt(), 0xFF5F5D57.toInt()),
                floatArrayOf(0f, .35f, .55f, 1f), Shader.TileMode.CLAMP))
            shaded(c, .452f, LinearGradient(.3f, .4f, -.3f, -.4f,
                intArrayOf(0xFFF1EEE6.toInt(), 0xFF76746D.toInt(), 0xFFE4E1D8.toInt()),
                floatArrayOf(0f, .5f, 1f), Shader.TileMode.CLAMP))
            for (i in 0 until 120) { c.save(); c.rotate(i * 3f); c.drawRect(-.0012f, -.472f, .0012f, -.465f, pt(0x50000000)); c.restore() }
            for (i in 0 until 8) {
                c.save(); c.rotate(i * 45f); c.translate(0f, -.458f)
                disc(c, 0f, 0f, .0065f, 0xFF4B4A45.toInt()); c.rotate(i * 37f)
                line(c, -.005f, 0f, .005f, 0f, .0016f, 0xFFD9D6CC.toInt()); c.restore()
            }
            shaded(c, .44f, RadialGradient(-.1f, -.12f, .5f, 0xFF2F5649.toInt(), 0xFF10261E.toInt(), Shader.TileMode.CLAMP))
            shaded(c, .44f, SweepGradient(0f, 0f, IntArray(49) { if (it % 2 == 1) 0x12FFFFFF else 0x17000000 }, null))
            ring(c, 0f, 0f, .44f, .004f, 0x80000000.toInt())
            ring(c, 0f, 0f, .433f, .0016f, 0xCCD6B86C.toInt()); ring(c, 0f, 0f, .408f, .0016f, 0xCCD6B86C.toInt())
            shaded(c, .305f, RadialGradient(0f, 0f, .305f, 0xFF1B2D26.toInt(), 0xFF0A1310.toInt(), Shader.TileMode.CLAMP))
            pt(0x1AC8D7CD); var row = 0; var y = -.3f
            while (y < .3f) {
                var x = -.3f + (if (row % 2 == 1) .008f else 0f)
                while (x < .3f) { if (x * x + y * y < .29f * .29f) c.drawCircle(x, y, .006f, p); x += .016f }
                y += .0138f; row++
            }
            ring(c, 0f, 0f, .305f, .004f, BRASS)
            for (i in 0 until 60) {
                c.save(); c.rotate(i * 6f)
                if (i % 5 != 0) c.drawRect(-.0013f, -.427f, .0013f, -.413f, pt(0xE6F3EBCB.toInt()))
                else if (i == 0) { baton(c, -.016f, .006f); baton(c, .016f, .006f) }
                else if (i != 15) baton(c, 0f, .009f)
                c.restore()
            }
            return b
        }

        // ---------- layer 2: solid plates that sit on top of the gears, so all lettering stays readable ----------
        private fun buildPlates(w: Int, h: Int): Bitmap {
            val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); val c = Canvas(b)
            c.translate(cx, cy); c.scale(u, u)
            // brand plaque
            c.drawRoundRect(RectF(-.16f, -.255f, .16f, -.125f), .02f, .02f, pt(0xFF0B1511.toInt()))
            c.drawRoundRect(RectF(-.16f, -.255f, .16f, -.125f), .02f, .02f, pt(GOLD, .004f))
            c.drawRoundRect(RectF(-.15f, -.245f, .15f, -.135f), .014f, .014f, pt(0x80D6B86C.toInt(), .0014f))
            for (sx in floatArrayOf(-.14f, .14f)) for (sy in floatArrayOf(-.238f, -.142f)) disc(c, sx, sy, .0045f, GOLD)
            goldText(c, "NOMZIE", 0f, -.203f, .056f, serifBold, .12f)
            text(c, "AUTOMATIC", 0f, -.152f, .027f, CREAM, sansBold, .25f)
            // power-reserve dial
            c.save(); c.translate(-.2f, 0f)
            shaded(c, .108f, LinearGradient(-.1f, -.1f, .1f, .1f, 0xFFF1EEE6.toInt(), 0xFF6A6862.toInt(), Shader.TileMode.CLAMP))
            shaded(c, .1f, RadialGradient(0f, 0f, .1f, 0xFF16271F.toInt(), 0xFF08110D.toInt(), Shader.TileMode.CLAMP))
            ring(c, 0f, 0f, .1f, .003f, BRASS)
            for (i in 0..10) {
                val a = rad(200f + 14f * i); val major = i % 5 == 0; val r0 = if (major) .074f else .084f
                line(c, cos(a) * r0, sin(a) * r0, cos(a) * .096f, sin(a) * .096f, if (major) .005f else .003f, LUME)
            }
            text(c, "0", cos(rad(200f)) * .056f, sin(rad(200f)) * .056f, .03f, CREAM, sansBold)
            text(c, "20", 0f, -.056f, .03f, CREAM, sansBold)
            text(c, "40", cos(rad(340f)) * .056f, sin(rad(340f)) * .056f, .03f, CREAM, sansBold)
            text(c, "RESERVE", 0f, .066f, .021f, CREAM, sansBold, .15f)
            c.restore()
            // date window
            c.drawRect(.15f, -.05f, .35f, .05f, pt(0xFFF6F2E4.toInt()))
            pt(BLACK); p.shader = LinearGradient(0f, -.05f, 0f, -.015f, 0x66000000, 0x00000000, Shader.TileMode.CLAMP)
            c.drawRect(.15f, -.05f, .35f, -.015f, p)
            line(c, .255f, -.05f, .255f, .05f, .002f, 0x40000000)
            c.drawRect(.15f, -.05f, .35f, .05f, pt(GOLD, .007f))
            // tourbillon window
            c.save(); c.translate(0f, .2f)
            shaded(c, .108f, LinearGradient(-.1f, -.1f, .1f, .1f, 0xFFF1EEE6.toInt(), 0xFF6A6862.toInt(), Shader.TileMode.CLAMP))
            shaded(c, .097f, RadialGradient(0f, 0f, .097f, 0xFF1A2B25.toInt(), 0xFF0A1310.toInt(), Shader.TileMode.CLAMP))
            c.restore()
            return b
        }

        private fun buildStatic(w: Int, h: Int) {
            bm?.recycle(); ov?.recycle()
            bm = buildBase(w, h); ov = buildPlates(w, h)
        }

        // ---------- every frame ----------
        private fun render(c: Canvas) {
            val b = bm ?: return
            val o = ov ?: return
            c.drawBitmap(b, 0f, 0f, null)
            val now = System.currentTimeMillis(); val dt = min(100L, now - last).toFloat(); last = now
            reserve = max(.3f, reserve - dt * 1e-6f)
            if (now < windEnd) { crown += dt * .0002f; reserve = min(1f, reserve + dt * .0002f) }
            val cal = Calendar.getInstance().apply { timeInMillis = now }
            val s = cal.get(Calendar.SECOND) + cal.get(Calendar.MILLISECOND) / 1000f
            val m = cal.get(Calendar.MINUTE); val hr = cal.get(Calendar.HOUR)
            val tb = now / 125.0; val stp = floor(tb); val f = (tb - stp).toFloat()
            val e = 1f - exp(-f * 16f) * cos(f * 34f)      // 8 beats a second, small overshoot each beat
            bt = stp + e
            val secDeg = (((stp % 480.0) + e) * .75).toFloat()
            val minDeg = (m + s / 60f) * 6f
            val hrDeg = (hr + m / 60f + s / 3600f) * 30f

            // gear train across the whole dial, driven beat by beat
            c.save(); c.translate(cx, cy); c.scale(u, u)
            val rimDeg = spin(.02) * 57.29578f
            for (i in 0 until 80) { c.save(); c.rotate(rimDeg + i * 4.5f); c.drawRect(-.0032f, -.318f, .0032f, -.304f, pt(GOLD)); c.restore() }
            val rC = spin(.012)
            gear(c, 0f, 0f, .13f, 26, rC, goldCols)
            gear(c, -.2f, -.12f, .11f, 22, mesh(rC, 26, 22, atan2(-.12f, -.2f)), steelCols)
            gear(c, .18f, -.13f, .10f, 20, mesh(rC, 26, 20, atan2(-.13f, .18f)), steelCols)
            gear(c, -.17f, .15f, .09f, 18, mesh(rC, 26, 18, atan2(.15f, -.17f)), goldCols)
            gear(c, .17f, .15f, .09f, 18, mesh(rC, 26, 18, atan2(.15f, .17f)), goldCols)
            c.restore()

            c.drawBitmap(o, 0f, 0f, null)

            c.save(); c.translate(cx, cy); c.scale(u, u)
            // reserve: mainspring coils tighten as it is wound, needle shows the charge
            c.save(); c.translate(-.2f, 0f)
            path.reset(); val aMax = TAU * (2.5f + reserve * 3f); var a = 0f
            while (a <= aMax) {
                val r = .008f + a / aMax * .045f
                if (a == 0f) path.moveTo(r, 0f) else path.lineTo(cos(a) * r, sin(a) * r); a += .25f
            }
            c.drawPath(path, pt(0x66B9985A, .0016f))
            c.rotate(200f + 140f * reserve)
            pt(RED, .005f); p.strokeCap = Paint.Cap.ROUND; c.drawLine(-.02f, 0f, .085f, 0f, p)
            disc(c, .075f, 0f, .006f, LUME); disc(c, 0f, 0f, .011f, BRASS); disc(c, 0f, 0f, .004f, PLATE)
            c.restore()

            val dow = cal.get(Calendar.DAY_OF_WEEK)
            text(c, days[dow - 1], .2025f, .003f, .036f, if (dow == Calendar.SUNDAY) 0xFFB3261E.toInt() else 0xFF14201B.toInt(), sansBold, .08f)
            text(c, cal.get(Calendar.DAY_OF_MONTH).toString(), .3025f, .003f, .066f, 0xFF14201B.toInt(), sansBold)

            // tourbillon: cage turns once a minute, carrying balance, escape wheel and pallet fork
            c.save(); c.translate(0f, .2f)
            path.reset(); path.addCircle(0f, 0f, .092f, Path.Direction.CW); c.clipPath(path)
            gear(c, 0f, 0f, .03f, 14, 0f, steelCols, false)
            c.save(); c.rotate((now % 60000L) / 60000f * 360f)
            ring(c, 0f, 0f, .062f, .005f, 0xFFCFD6D2.toInt()); line(c, -.062f, 0f, .062f, 0f, .005f, 0xFFCFD6D2.toInt())
            for (i in 0 until 3) disc(c, cos(i * TAU / 3) * .062f, sin(i * TAU / 3) * .062f, .006f, BRASS)
            val tgt = if (stp.toLong() % 2L == 0L) 1f else -1f
            c.save(); c.translate(0f, .042f); c.rotate((-tgt + 2f * tgt * e) * 10f)
            path.reset(); path.moveTo(-.016f, .01f); path.lineTo(0f, 0f); path.lineTo(.016f, .01f)
            c.drawPath(path, pt(GOLD, .004f)); line(c, 0f, 0f, 0f, -.03f, .003f, GOLD); disc(c, 0f, -.031f, .004f, RUBY)
            c.restore()
            gear(c, .034f, .024f, .022f, 12, spin(.2618), goldCols, false)
            c.save(); c.translate(-.02f, -.012f)
            val ang = (.85 * sin(TAUD * 4.0 * (now / 1000.0))).toFloat()   // 4 Hz balance
            c.rotate(ang * 57.29578f)
            c.save(); val sc = 1f + .09f * sin(ang); c.scale(sc, sc)
            path.reset(); var q = 0f
            while (q < TAU * 4) { val r = .006f + q / (TAU * 4) * .022f; if (q == 0f) path.moveTo(r, 0f) else path.lineTo(cos(q) * r, sin(q) * r); q += .2f }
            c.drawPath(path, pt(0xFFCFD6D2.toInt(), .0013f)); c.restore()
            ring(c, 0f, 0f, .034f, .006f, GOLD)
            for (i in 0 until 3) line(c, 0f, 0f, cos(i * TAU / 3) * .032f, sin(i * TAU / 3) * .032f, .0035f, GOLD)
            for (i in 0 until 8) disc(c, cos(i * TAU / 8) * .034f, sin(i * TAU / 8) * .034f, .0035f, 0xFFF0DD9A.toInt())
            disc(c, 0f, 0f, .006f, RUBY)
            c.restore(); c.restore()
            c.drawArc(RectF(-.08f, -.08f, .08f, .08f), 205f, 130f, false, pt(0xFF8A7440.toInt(), .012f))
            for (dg in floatArrayOf(205f, 335f)) disc(c, cos(rad(dg)) * .08f, sin(rad(dg)) * .08f, .0065f, RUBY)
            c.restore()

            // crown
            pt(BLACK); p.shader = LinearGradient(0f, -.04f, 0f, .04f,
                intArrayOf(0xFF8D8B84.toInt(), 0xFFECEAE2.toInt(), 0xFF6A6862.toInt()), floatArrayOf(0f, .45f, 1f), Shader.TileMode.CLAMP)
            c.drawRect(.468f, -.04f, .498f, .04f, p)
            var ry = -.04f + (crown % .01f)
            while (ry < .04f) { line(c, .468f, ry, .498f, ry, .0025f, 0x73000000); ry += .01f }

            // hands, shadow pass then real pass
            c.save(); c.translate(.004f, .009f)
            hand(c, hrDeg, .25f, .03f, .05f, true); hand(c, minDeg, .385f, .021f, .06f, true); secHand(c, secDeg, true)
            c.restore()
            hand(c, hrDeg, .25f, .03f, .05f, false); hand(c, minDeg, .385f, .021f, .06f, false); secHand(c, secDeg, false)
            disc(c, 0f, 0f, .016f, BRASS); disc(c, 0f, 0f, .006f, 0xFF10261E.toInt())

            pt(BLACK); p.shader = LinearGradient(-.35f, -.4f, .15f, .1f, 0x29FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
            c.drawCircle(0f, 0f, .44f, p)
            c.restore()
        }

        private fun draw() {
            if (bm == null) return
            val c = (try { surfaceHolder.lockHardwareCanvas() } catch (e: Exception) { null }) ?: return
            try { render(c) } finally { surfaceHolder.unlockCanvasAndPost(c) }
        }

        // ---------- engine lifecycle, touch, motion ----------
        override fun onCreate(holder: SurfaceHolder) { super.onCreate(holder); setTouchEventsEnabled(true) }
        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            if (width == 0 || height == 0) return
            u = min(width, height) * .94f; cx = width / 2f; cy = height * .46f
            buildStatic(width, height); draw()
        }
        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            shown = false; handler.removeCallbacks(tick); super.onSurfaceDestroyed(holder)
        }
        override fun onVisibilityChanged(visible: Boolean) {
            shown = visible
            if (visible) {
                handler.post(tick)
                sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
            } else { handler.removeCallbacks(tick); sm.unregisterListener(this) }
        }
        override fun onDestroy() { shown = false; handler.removeCallbacks(tick); sm.unregisterListener(this); super.onDestroy() }
        override fun onTouchEvent(event: MotionEvent) {
            if (event.actionMasked == MotionEvent.ACTION_DOWN) {
                val nx = (event.x - cx) / u; val ny = (event.y - cy) / u
                if ((nx > .36f && abs(ny) < .14f) || hypot(nx + .2f, ny) < .13f) windEnd = System.currentTimeMillis() + 700
            }
        }
        override fun onSensorChanged(event: SensorEvent?) {   // shaking the phone winds the automatic movement
            val v = event?.values ?: return
            val g = sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]) - 9.81f
            if (abs(g) > 1.5f) reserve = min(1f, reserve + abs(g) * .0004f)
        }
        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }
}
