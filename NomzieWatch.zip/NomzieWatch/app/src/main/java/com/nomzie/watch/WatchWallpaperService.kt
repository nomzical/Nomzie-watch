package com.nomzie.watch

import android.content.Context
import android.graphics.*
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.MotionEvent
import android.view.SurfaceHolder
import java.util.Calendar
import kotlin.math.*

private const val TAU = 6.2831855f
private const val TAUD = 6.283185307179586
private val BRASS = 0xFFB9985A.toInt()
private val LUME = 0xFFE3ECC4.toInt()
private val RED = 0xFFE2552F.toInt()
private val STEEL = 0xFFCFD6D2.toInt()
private val GOLD = 0xFFD6B86C.toInt()
private val PLATE = 0xFF0C1713.toInt()
private val CREAM = 0xFFEFE6C6.toInt()
private val RUBY = 0xFFC4362C.toInt()
private fun rad(d: Float) = d * 0.017453292f

class WatchWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = WatchEngine()

    inner class WatchEngine : Engine(), SensorEventListener {
        private val handler = Handler(Looper.getMainLooper())
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val path = Path()
        private val sm by lazy { this@WatchWallpaperService.getSystemService(Context.SENSOR_SERVICE) as SensorManager }
        private val serifItalic = Typeface.create(Typeface.SERIF, Typeface.ITALIC)
        private val sansMedium = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        private val days = arrayOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
        private var bm: Bitmap? = null
        private var cx = 0f; private var cy = 0f; private var u = 1f
        private var reserve = 0.8f; private var crown = 0f
        private var windEnd = 0L; private var last = System.currentTimeMillis()
        private var bt = 0.0
        private var shown = false
        private val tick = object : Runnable {
            override fun run() { draw(); if (shown) handler.postDelayed(this, 33) }
        }

        // ---------- small drawing helpers ----------
        private fun pt(color: Int, stroke: Float = 0f): Paint {
            p.reset(); p.isAntiAlias = true; p.color = color
            if (stroke > 0f) { p.style = Paint.Style.STROKE; p.strokeWidth = stroke } else p.style = Paint.Style.FILL
            return p
        }
        private fun disc(c: Canvas, x: Float, y: Float, r: Float, color: Int) = c.drawCircle(x, y, r, pt(color))
        private fun ring(c: Canvas, x: Float, y: Float, r: Float, w: Float, color: Int) = c.drawCircle(x, y, r, pt(color, w))
        private fun line(c: Canvas, x0: Float, y0: Float, x1: Float, y1: Float, w: Float, color: Int) =
            c.drawLine(x0, y0, x1, y1, pt(color, w))
        private fun shaded(c: Canvas, r: Float, sh: Shader) { pt(0xFF000000.toInt()); p.shader = sh; c.drawCircle(0f, 0f, r, p) }
        private fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, tf: Typeface) {
            pt(color); p.typeface = tf; p.textSize = size; p.textAlign = Paint.Align.CENTER
            c.drawText(s, x, y + size * 0.35f, p)
        }
        private fun spin(perBeat: Double) = ((bt * perBeat) % TAUD).toFloat()

        private val GR = floatArrayOf(.82f, 1f, 1f, .82f)
        private val GO = floatArrayOf(0f, .12f, .42f, .55f)
        private fun gear(c: Canvas, x: Float, y: Float, r: Float, n: Int, rot: Float, color: Int, open: Boolean = true) {
            val k = TAU / n
            path.reset()
            for (i in 0 until n) for (j in 0..3) {
                val a = rot + (i + GO[j]) * k; val rr = r * GR[j]
                val px = x + cos(a) * rr; val py = y + sin(a) * rr
                if (i == 0 && j == 0) path.moveTo(px, py) else path.lineTo(px, py)
            }
            path.close(); c.drawPath(path, pt(color))
            if (open) {
                disc(c, x, y, r * .66f, PLATE)
                for (i in 0 until 5) {
                    val a = rot + i * TAU / 5
                    line(c, x, y, x + cos(a) * r * .7f, y + sin(a) * r * .7f, r * .09f, color)
                }
                disc(c, x, y, r * .16f, color)
            }
        }
        // rotation for gear B so its teeth sit in the gaps of gear A (B lies in direction alpha from A)
        private fun mesh(rotA: Float, nA: Int, nB: Int, alpha: Float): Float {
            val kA = TAU / nA; val kB = TAU / nB
            return -(nA.toFloat() / nB) * (rotA - (alpha - .275f * kA)) + alpha + PI.toFloat() - .775f * kB
        }
        private fun baton(c: Canvas, x: Float, hw: Float) {
            c.drawRect(x - hw, -.405f, x + hw, -.335f, pt(LUME))
            c.drawRect(x - hw, -.405f, x + hw, -.335f, pt(BRASS, .0025f))
        }
        private fun hand(c: Canvas, deg: Float, len: Float, w: Float, tail: Float, shade: Boolean) {
            c.save(); c.rotate(deg)
            path.reset(); path.moveTo(0f, tail); path.lineTo(-w, 0f); path.lineTo(0f, -len); path.lineTo(w, 0f); path.close()
            if (shade) c.drawPath(path, pt(0x73000000)) else {
                c.drawPath(path, pt(0xFFECE8DC.toInt())); c.drawPath(path, pt(BRASS, .003f))
                path.reset(); path.moveTo(0f, tail * .3f); path.lineTo(-w * .5f, 0f); path.lineTo(0f, -len * .88f); path.lineTo(w * .5f, 0f); path.close()
                c.drawPath(path, pt(LUME))
            }
            c.restore()
        }
        private fun secHand(c: Canvas, deg: Float, shade: Boolean) {
            c.save(); c.rotate(deg)
            val col = if (shade) 0x73000000 else RED
            line(c, 0f, .11f, 0f, -.405f, .0035f, col); disc(c, 0f, .085f, .016f, col)
            if (!shade) disc(c, 0f, -.3f, .007f, LUME)
            c.restore()
        }

        // ---------- static layers: case, dial, plate, markers, labels ----------
        private fun buildStatic(w: Int, h: Int) {
            bm?.recycle()
            val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); val c = Canvas(b)
            pt(0); p.shader = RadialGradient(cx, cy, max(w, h) * .7f, 0xFF18221D.toInt(), 0xFF050806.toInt(), Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
            c.translate(cx, cy); c.scale(u, u)
            for (i in 0 until 6) disc(c, 0f, .014f, .472f + i * .005f, 0x12000000)
            shaded(c, .472f, LinearGradient(-.4f, -.45f, .4f, .45f,
                intArrayOf(0xFFF1EEE6.toInt(), 0xFF8A8880.toInt(), 0xFFD6D3C9.toInt(), 0xFF5F5D57.toInt()),
                floatArrayOf(0f, .35f, .55f, 1f), Shader.TileMode.CLAMP))
            shaded(c, .452f, LinearGradient(.3f, .4f, -.3f, -.4f,
                intArrayOf(0xFFF1EEE6.toInt(), 0xFF76746D.toInt(), 0xFFE4E1D8.toInt()),
                floatArrayOf(0f, .5f, 1f), Shader.TileMode.CLAMP))
            for (i in 0 until 8) { // screwed-down bezel
                c.save(); c.rotate(i * 45f); c.translate(0f, -.462f)
                disc(c, 0f, 0f, .0065f, 0xFF4B4A45.toInt()); c.rotate(i * 37f)
                line(c, -.005f, 0f, .005f, 0f, .0016f, 0xFFD9D6CC.toInt()); c.restore()
            }
            shaded(c, .44f, RadialGradient(-.1f, -.12f, .5f, 0xFF2F5649.toInt(), 0xFF10261E.toInt(), Shader.TileMode.CLAMP))
            shaded(c, .44f, SweepGradient(0f, 0f, IntArray(49) { if (it % 2 == 1) 0x12FFFFFF else 0x17000000 }, null))
            ring(c, 0f, 0f, .44f, .004f, 0x80000000.toInt())
            // movement plate with perlage
            shaded(c, .305f, RadialGradient(0f, 0f, .305f, 0xFF1B2D26.toInt(), 0xFF0A1310.toInt(), Shader.TileMode.CLAMP))
            pt(0x1AC8D7CD); var row = 0; var y = -.3f
            while (y < .3f) {
                var x = -.3f + (if (row % 2 == 1) .008f else 0f)
                while (x < .3f) { if (x * x + y * y < .29f * .29f) c.drawCircle(x, y, .006f, p); x += .016f }
                y += .0138f; row++
            }
            ring(c, 0f, 0f, .305f, .004f, BRASS)
            for (i in 0 until 60) {
                c.save(); c.rotate(i * 6f)
                if (i % 5 != 0) c.drawRect(-.0012f, -.425f, .0012f, -.411f, pt(0xCCEFE8CD.toInt()))
                else if (i == 0) { baton(c, -.016f, .006f); baton(c, .016f, .006f) }
                else if (i != 15) baton(c, 0f, .009f)
                c.restore()
            }
            text(c, "Nomzie", 0f, -.265f, .05f, CREAM, serifItalic)
            text(c, "automatic", 0f, -.222f, .026f, 0xB3EFE8CD.toInt(), serifItalic)
            // power-reserve subdial
            c.save(); c.translate(-.21f, 0f)
            disc(c, 0f, 0f, .09f, 0xFF0C1C16.toInt()); ring(c, 0f, 0f, .09f, .003f, BRASS)
            for (i in 0..6) {
                val a = rad(200f + 140f * i / 6f)
                line(c, cos(a) * .066f, sin(a) * .066f, cos(a) * .08f, sin(a) * .08f, .003f, LUME)
            }
            text(c, "0", -.055f, .026f, .026f, CREAM, sansMedium); text(c, "40h", .055f, .026f, .026f, CREAM, sansMedium)
            text(c, "reserve", 0f, .056f, .024f, 0xB3EFE8CD.toInt(), serifItalic)
            c.restore()
            // date window
            c.drawRect(.17f, -.04f, .34f, .04f, pt(0xFFF4F0E2.toInt()))
            c.drawRect(.17f, -.04f, .34f, .04f, pt(BRASS, .004f))
            line(c, .255f, -.04f, .255f, .04f, .002f, 0x40000000)
            // tourbillon window
            c.save(); c.translate(0f, .2f)
            shaded(c, .095f, RadialGradient(0f, 0f, .095f, 0xFF1A2B25.toInt(), 0xFF0A1310.toInt(), Shader.TileMode.CLAMP))
            ring(c, 0f, 0f, .097f, .006f, BRASS)
            c.restore()
            bm = b
        }

        // ---------- every frame ----------
        private fun render(c: Canvas) {
            val b = bm ?: return
            c.drawBitmap(b, 0f, 0f, null)
            val now = System.currentTimeMillis(); val dt = min(100L, now - last).toFloat(); last = now
            reserve = max(.3f, reserve - dt * 1e-6f)
            if (now < windEnd) { crown += dt * .0002f; reserve = min(1f, reserve + dt * .0002f) }
            val cal = Calendar.getInstance().apply { timeInMillis = now }
            val s = cal.get(Calendar.SECOND) + cal.get(Calendar.MILLISECOND) / 1000f
            val m = cal.get(Calendar.MINUTE); val hr = cal.get(Calendar.HOUR)
            val tb = now / 125.0; val stp = floor(tb); val f = (tb - stp).toFloat()
            val e = 1f - exp(-f * 16f) * cos(f * 34f)      // 8 beats a second, small overshoot each beat
            bt = stp + e
            val secDeg = (((stp % 480.0) + e) * .75).toFloat()
            val minDeg = (m + s / 60f) * 6f
            val hrDeg = (hr + m / 60f + s / 3600f) * 30f

            c.save(); c.translate(cx, cy); c.scale(u, u)
            // going train: two meshing pairs, centre wheel turning with the minute hand
            val rA = spin(.05)
            gear(c, -.19f, -.17f, .06f, 20, rA, GOLD)
            gear(c, -.12f, -.12f, .03f, 10, mesh(rA, 20, 10, atan2(.05f, .07f)), STEEL)
            gear(c, .19f, -.17f, .06f, 20, -rA, GOLD)
            gear(c, .12f, -.12f, .03f, 10, mesh(-rA, 20, 10, atan2(.05f, -.07f)), STEEL)
            gear(c, 0f, 0f, .075f, 30, -rad(minDeg), 0x99D6B86C.toInt())

            // power reserve: mainspring coils tighten as it is wound
            c.save(); c.translate(-.21f, 0f)
            path.reset(); val aMax = TAU * (2.5f + reserve * 3f); var a = 0f
            while (a <= aMax) {
                val r = .008f + a / aMax * .05f
                if (a == 0f) path.moveTo(r, 0f) else path.lineTo(cos(a) * r, sin(a) * r); a += .25f
            }
            c.drawPath(path, pt(0x66B9985A, .0016f))
            c.rotate(200f + 140f * reserve)
            pt(RED, .004f); p.strokeCap = Paint.Cap.ROUND; c.drawLine(0f, 0f, .068f, 0f, p)
            disc(c, 0f, 0f, .007f, BRASS)
            c.restore()

            text(c, days[cal.get(Calendar.DAY_OF_WEEK) - 1], .2125f, .003f, .034f, 0xFF10261E.toInt(), sansMedium)
            text(c, cal.get(Calendar.DAY_OF_MONTH).toString(), .2975f, .003f, .044f, 0xFF10261E.toInt(), sansMedium)

            // tourbillon: cage turns once a minute, carrying balance, escape wheel and pallet fork
            c.save(); c.translate(0f, .2f)
            path.reset(); path.addCircle(0f, 0f, .092f, Path.Direction.CW); c.clipPath(path)
            gear(c, 0f, 0f, .03f, 14, 0f, 0xFF9AA39F.toInt(), false)
            c.save(); c.rotate((now % 60000L) / 60000f * 360f)
            ring(c, 0f, 0f, .062f, .005f, STEEL); line(c, -.062f, 0f, .062f, 0f, .005f, STEEL)
            for (i in 0 until 3) disc(c, cos(i * TAU / 3) * .062f, sin(i * TAU / 3) * .062f, .006f, BRASS)
            val tgt = if (stp.toLong() % 2L == 0L) 1f else -1f
            c.save(); c.translate(0f, .042f); c.rotate((-tgt + 2f * tgt * e) * 10f)
            path.reset(); path.moveTo(-.016f, .01f); path.lineTo(0f, 0f); path.lineTo(.016f, .01f)
            c.drawPath(path, pt(GOLD, .004f)); line(c, 0f, 0f, 0f, -.03f, .003f, GOLD); disc(c, 0f, -.031f, .004f, RUBY)
            c.restore()
            gear(c, .034f, .024f, .022f, 12, spin(.2618), GOLD, false)
            c.save(); c.translate(-.02f, -.012f)
            val ang = (.85 * sin(TAUD * 4.0 * (now / 1000.0))).toFloat()   // 4 Hz balance
            c.rotate(ang * 57.29578f)
            c.save(); val sc = 1f + .09f * sin(ang); c.scale(sc, sc)
            path.reset(); var q = 0f
            while (q < TAU * 4) { val r = .006f + q / (TAU * 4) * .022f; if (q == 0f) path.moveTo(r, 0f) else path.lineTo(cos(q) * r, sin(q) * r); q += .2f }
            c.drawPath(path, pt(STEEL, .0013f)); c.restore()
            ring(c, 0f, 0f, .034f, .006f, GOLD)
            for (i in 0 until 3) line(c, 0f, 0f, cos(i * TAU / 3) * .032f, sin(i * TAU / 3) * .032f, .0035f, GOLD)
            for (i in 0 until 8) disc(c, cos(i * TAU / 8) * .034f, sin(i * TAU / 8) * .034f, .0035f, 0xFFF0DD9A.toInt())
            disc(c, 0f, 0f, .006f, RUBY)
            c.restore(); c.restore()
            c.drawArc(RectF(-.08f, -.08f, .08f, .08f), 205f, 130f, false, pt(0xFF8A7440.toInt(), .012f))
            for (dg in floatArrayOf(205f, 335f)) disc(c, cos(rad(dg)) * .08f, sin(rad(dg)) * .08f, .0065f, RUBY)
            c.restore()

            // crown
            pt(0); p.shader = LinearGradient(0f, -.04f, 0f, .04f,
                intArrayOf(0xFF8D8B84.toInt(), 0xFFECEAE2.toInt(), 0xFF6A6862.toInt()), floatArrayOf(0f, .45f, 1f), Shader.TileMode.CLAMP)
            c.drawRect(.468f, -.04f, .498f, .04f, p)
            var ry = -.04f + (crown % .01f)
            while (ry < .04f) { line(c, .468f, ry, .498f, ry, .0025f, 0x73000000); ry += .01f }

            // hands, shadow pass then real pass
            c.save(); c.translate(.004f, .009f)
            hand(c, hrDeg, .24f, .026f, .05f, true); hand(c, minDeg, .37f, .018f, .06f, true); secHand(c, secDeg, true)
            c.restore()
            hand(c, hrDeg, .24f, .026f, .05f, false); hand(c, minDeg, .37f, .018f, .06f, false); secHand(c, secDeg, false)
            disc(c, 0f, 0f, .014f, BRASS); disc(c, 0f, 0f, .005f, 0xFF10261E.toInt())

            pt(0); p.shader = LinearGradient(-.35f, -.4f, .15f, .1f, 0x29FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
            c.drawCircle(0f, 0f, .44f, p)
            c.restore()
        }

        private fun draw() {
            if (bm == null) return
            val c = (try { surfaceHolder.lockHardwareCanvas() } catch (e: Exception) { null }) ?: return
            try { render(c) } finally { surfaceHolder.unlockCanvasAndPost(c) }
        }

        // ---------- engine lifecycle, touch, motion ----------
        override fun onCreate(holder: SurfaceHolder) { super.onCreate(holder); setTouchEventsEnabled(true) }
        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            if (width == 0 || height == 0) return
            u = min(width, height) * .94f; cx = width / 2f; cy = height * .46f
            buildStatic(width, height); draw()
        }
        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            shown = false; handler.removeCallbacks(tick); super.onSurfaceDestroyed(holder)
        }
        override fun onVisibilityChanged(visible: Boolean) {
            shown = visible
            if (visible) {
                handler.post(tick)
                sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
            } else { handler.removeCallbacks(tick); sm.unregisterListener(this) }
        }
        override fun onDestroy() { shown = false; handler.removeCallbacks(tick); sm.unregisterListener(this); super.onDestroy() }
        override fun onTouchEvent(event: MotionEvent) {
            if (event.actionMasked == MotionEvent.ACTION_DOWN) {
                val nx = (event.x - cx) / u; val ny = (event.y - cy) / u
                if ((nx > .36f && abs(ny) < .14f) || hypot(nx + .21f, ny) < .12f) windEnd = System.currentTimeMillis() + 700
            }
        }
        override fun onSensorChanged(event: SensorEvent?) {   // shaking the phone winds the automatic movement
            val v = event?.values ?: return
            val g = sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]) - 9.81f
            if (abs(g) > 1.5f) reserve = min(1f, reserve + abs(g) * .0004f)
        }
        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }
}
