plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.nomzie.watch"
    compileSdk = 34
    defaultConfig { applicationId = "com.nomzie.watchface"; minSdk = 26; targetSdk = 34; versionCode = 2; versionName = "1.1" }
    signingConfigs {
        create("nomzie") {
            storeFile = file("nomzie.jks"); storePassword = "nomzie123"
            keyAlias = "nomzie"; keyPassword = "nomzie123"
        }
    }
    buildTypes { getByName("debug") { signingConfig = signingConfigs.getByName("nomzie") } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
